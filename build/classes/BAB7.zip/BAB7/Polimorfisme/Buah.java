/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BAB7.Polimorfisme;

/**
 *
 * @author teguh
 */
public class Buah {
    public String nama;
    public void setNamaBuah(){
    this.nama = "Apel, mangga, pisang,jambu,dll";
    }
    void makanBuah(){
        System.out.println("Makan Buah secara umum");
    }
}
